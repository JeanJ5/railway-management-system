<?php
        session_start();
        if ($_SESSION['login']==true){}
        else{
            echo "Illegal attempt. Login failed";
            die;
        }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Home-Habibi Railways</title>
    <style>
        body{
            padding: 0px;
            margin: 0px;
            min-height: 100vh;
        }
        .header{
            background-color: #f1f1f1;
            padding: 20px 20px;
        }
        .navigation{
            position: fixed;
            height: 100vh;
            width: 220px;
            background-color: gray;
            display: flex;
            flex-direction: column;
            justify-content: space-evenly;
        }
        .tags{
            background-color: #fff;
            margin-left: 20px;
            padding: 5px;
        }
        .tags a{
            position: relative;
            width: 100%;
            text-decoration: none;
            color: #333;
            display: flex;
            justify-content: space-evenly;
        }
        .icon{
            position: relative;
            
            
        }
        .icon ion-icon{
            font-size: 1.5em;
        }
        .title{
            position: relative;
            top: 1.8px;
            font-size: 15px;
            padding: 3px;
            width: 100px;
            
        }
        
        
    </style>
</head>
<body>
    <div class="header">
    <a href="#default" class="logo">CompanyLogo</a>
    <div class="header-right">
        <a href="#contact">Contact</a>
        <a href="#about">About</a>
    </div>
    </div>
    <div class="navigation">
        <div class="tags">
            <a href="#">
                <div class="icon"><ion-icon name="home-outline"></ion-icon></div>
                <div class="title">Home</div>
            </a>
        </div>
        <div class="tags">
            <a href="#">
                <div class="icon"><ion-icon name="person-outline"></ion-icon></div>
                <div class="title">Profile</div>
            </a>
        </div>
        <div class="tags">
            <a href="#">
                <div class="icon"><ion-icon name="ticket-outline"></ion-icon></div>
                <div class="title">Book Ticket</div>
            </a>
        </div>
        <div class="tags">
            <a href="#">
                <div class="icon"><ion-icon name="train-outline"></ion-icon></div>
                <div class="title">Find Train</div>
            </a>
        </div>
        <div class="tags">
            <a href="#">
                <div class="icon"><ion-icon name="book-outline"></ion-icon></div>
                <div class="title">History</div>
            </a>
        </div>
        <div class="tags">
            <a href="#">
                <div class="icon"><ion-icon name="help-outline"></ion-icon></div>
                <div class="title">Help</div>
            </a>
        </div>        
    </div>
    <div class="content">

    </div>
    <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
</body>
</html>