<?php
    header('location:main.html');
?>