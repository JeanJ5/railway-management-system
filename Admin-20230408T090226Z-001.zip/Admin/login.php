<?php
    session_start();
    $_SESSION['login'] = false;

    $uname=$_POST['uname'];
    $upass=$_POST['upass'];

    include_once "../Shared/connection.php";

    $input_hash = md5($upass);

    $cmd = "select * from user where username='$uname' and password='$input_hash'";
    $sql_result = mysqli_query($conn,$cmd);

    $total_row_count = mysqli_num_rows($sql_result);
    if($total_row_count == 1){
        $_SESSION['login'] = true;
        echo "Login Success";
        header('location:home.php');
    }
    else{
        echo '<script>
                alert("Couldn\'t find your Account");
        </script>';
        echo mysqli_error($conn);
    }

 ?>