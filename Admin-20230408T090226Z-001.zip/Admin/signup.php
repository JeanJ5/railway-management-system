<?php

    session_start();
    $_SESSION['login'] = false;

    $uname = $_POST["uname"];
    $pass1 = $_POST["upass1"];
    $pass2 = $_POST["upass2"];

    if($pass1 != $pass2){
        echo "Pasword mismatch";
        die;
    }

    include_once "../Shared/connection.php";            //Estabish connection with db

    $cmd = "select * from user where username='$uname'"; 
    $sql_result = mysqli_query($conn,$cmd);             //Execute sql query

    $total_row_count = mysqli_num_rows($sql_result);
    if($total_row_count > 0){
        echo "Username already taken, try different username";
        die();
    }

    $hash = md5($pass1);

    $query = "insert into user(username,password) values('$uname','$hash')";
    $sql_status = mysqli_query($conn,$query);

    if($sql_status){
        $_SESSION['login'] = true;
        echo "SignUp success";
        header("location:home.php");
    }
    else{
        echo "SignUp failed";
        echo mysqli_error($conn);
    }
?>