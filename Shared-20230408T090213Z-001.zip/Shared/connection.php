<?php
    $conn = new mysqli("localhost","root","","habibirailways");

    if($conn->connect_error)
    {
        echo "Connection failed";
        die;
    }
?>